import java.text.DecimalFormat;

import javax.swing.JOptionPane;

/**
 * 
 */

/**
 * @author Sathu. K
 * Date: May 24, 2023
 * Description: Create a program that will take the amount of money invested, the interest rate 
 *              and the number of years for the investment and the program will calculate the 
 *              future value of the investment using methods
 * 
 * Method List
 * -boolean checkInput (double years) - this is method is check if correct input to see if true of false 
 * -double calculateInvestment(double startingAmount, double interestRate, int years) - the program calculates the future value 
 * -void main(String[] args)
 *
 */
public class InvestmentCalculator {

	/**
	 *  Method to Calculates the future value of an investment of a starting amount of money
	 *  based on the interest rate and the number of years the investment will last.
	 */
	public static double calculateInvestment (double startingAmount, double interestRate, int years) {

		double futureValue = startingAmount * Math.pow(( 1 + (interestRate/100)), years); // Calculates the future value

		return futureValue;  // return futureValue to the method
	}

	/*
	 * Method Checks if the input is valid. Valid inputs are non-negative
	 */
	public static boolean checkInput (double input) {

		boolean value; // declare variable as boolean

		if (input >= 0) { 	// if number entered is greater or equal to zero the boolean is returned true


			return true;   
		}
		else {				// else boolean is returned false

			return false;	
		}
		

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Declare varibles needed
		int years;
		double startingAmount, interestRate, futureValue;
		
		
		// Set up decimal format to two decimal places
		DecimalFormat twoDecimals = new DecimalFormat ("0.00");

		// loop if the number entered is negative
		while(true) {
			years = Integer.parseInt(JOptionPane.showInputDialog("Enter the duration of the investment in years")); // prompt user for the amount of years
			if (checkInput(years)) { // calling the method check input
				break;
			}
			years = IO.readInt("What is the duration of the investment: "); // prompts user to enter again
			}
			

		
		// loop if the number entered is negative
		while(true) {
			startingAmount = Double.parseDouble(JOptionPane.showInputDialog("Enter starting amount")); // prompt user for the starting amount of investment
			if (checkInput(startingAmount)) { // calling the method check input
				break;
			}
			startingAmount = IO.readDouble("Enter the starting amount of the investment: "); // prompts user to enter again
		}
		
		
		// loop if the number entered is negative
		while(true) {
			interestRate = Double.parseDouble(JOptionPane.showInputDialog("Enter interest rate")); // prompt user for the interest rate of investment
			if (checkInput(interestRate)) { // calling the method check input
				break;
			}
			interestRate = IO.readDouble("Enter the interest rate of the investment: "); // prompt user again
		}

		
		// calling the method calculate investment to calculate the future value
		
		futureValue = calculateInvestment(startingAmount, interestRate, years);
		
		// Display the futureValue to the user
		
		IO.display("Starting Amount: $"+ startingAmount  +
				   "\nInterest Rate: " + interestRate + "%" +
				   "\nDuration of investment: " + years + " years" +
				   "\nFuture value: $" + twoDecimals.format(futureValue));

}


}
