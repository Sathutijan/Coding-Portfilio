import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 * 
 */

/**
 *  @author Sathu. K
 * Date: May 25, 2023
 * Description: This program will displays a GUI, in this GUI the program will ask to input three values the amount of years
 * , starting amount and the interest rate. the program will calculate the the future value with this inputs with the given formula 
 * of : future value = startingAmount * Math.pow((1 + interestRate/100), years). This program will then display the future value at 
 * the bottom of the GUI rounded to decimal places. The program will also display an error message if any of the values entered by the 
 * user are negative values in the GUI. The program also allows the user to exit the program as well as clearing any inputs.
 * Additionally the program will automatically clear the inputs if the input is a negative also displaying a error message.
 *
 * METHOD LIST: 
 *              - boolean checkInput (double years) - this is method is check if correct input to see if true of false 
 *              - double calculateInvestment(double startingAmount, double interestRate, int years) - the program calculates the future value 
 *              - void actionPerformed (ActionEvent e) - check the buttons when clicked
 *              - InvestmentCalculatorGUI() - constructor method to build the frame and display them
 *              - void main(String[] args) - Main method
 *              
 * LINK : https://stackoverflow.com/questions/1090098/newline-in-jlabel
 * Allows you to change lines in Jlabel 
 */
public class InvestmentCalculatorGUI extends JFrame implements ActionListener{

	// Declare variables needed 

	//declare variables for JLabels, text field, and Jbuttons
	JLabel lblYears, lblStartingAmount, lblInterestRate, lblfutureValue, lblPic, lblDescription; 
	JTextField txtInputYears, txtInputStartingAmount, txtInputInterestRate; 
	JButton btnCalculate, btnClear, btnExit; 

	/**
	 * 
	 */
	public InvestmentCalculatorGUI() {
		//name of the window
		super ("Sathu's Investment Calculator"); 

		//create buttons, labels, text boxes 
		lblYears = new JLabel("Years: ");
		lblStartingAmount = new JLabel("Starting Amount: "); 
		lblInterestRate = new JLabel ("Interest Rate: ");
		txtInputYears = new JTextField (""); 
		txtInputStartingAmount = new JTextField (""); 
		txtInputInterestRate = new JTextField ("");
		lblfutureValue = new JLabel("Please Enter Values Above");
		lblDescription = new JLabel("<html>*An Investment Calculator*<br/> That takes the amount of money to begin with, the interest rate for the investment and the number of years the investment will last to display the future value. <html><br/>Created by: Sathu Kugathasan");

		//create label for picture
		lblPic = new JLabel (new ImageIcon ("Calculator.png")); 

		//create buttons for calculate, clear and exit
		btnCalculate = new JButton ("Calculate");
		btnClear = new JButton ("Clear");
		btnExit = new JButton ("Exit"); 
		btnExit.setBackground(Color.YELLOW);

		//set size and layout, allow us to use the set bounds
		setLayout (null);
		setSize (450, 350);

		//place everything at required places
		lblYears.setBounds (10, 10, 200, 30);
		txtInputYears.setBounds (150, 10, 50, 30); 
		lblStartingAmount.setBounds (10, 50, 200, 30);
		txtInputStartingAmount.setBounds (150, 50, 50, 30);
		lblInterestRate.setBounds (10, 90, 200, 30);
		txtInputInterestRate.setBounds (150, 90, 50, 30); 
		btnCalculate.setBounds (10, 150, 190, 25);
		btnClear.setBounds (10, 180, 190, 25);
		btnExit.setBounds(293, 270, 95, 25 );
		lblPic.setBounds (240, 90, 200,200);
		lblfutureValue.setBounds (10, 215, 360, 80);
		lblDescription.setBounds (210, 10, 200, 110);

		// add the labels, text boxes and buttons to the frame
		add (lblYears);
		add (txtInputYears);
		add (lblStartingAmount);
		add (txtInputStartingAmount);
		add (lblInterestRate);
		add (txtInputInterestRate);
		add (lblfutureValue);
		add (btnCalculate);
		add (btnClear); 
		add (btnExit); 
		add (lblPic);
		add (lblDescription);

		//make the buttons listen to the clicks of the user
		btnCalculate.addActionListener (this);
		btnClear.addActionListener(this);
		btnExit.addActionListener(this);

		//show the window
		setVisible (true); 
	}


	/*
	 * Method to listen to events (clicking,typing,etc)
	 */
	public void actionPerformed(ActionEvent e) {


		// Set up decimal format to two decimal places
		DecimalFormat twoDecimals = new DecimalFormat ("0.00");

		// check which button was clicked

		//if the calculate is clicked
		if (e.getSource () == btnCalculate)
		{
			// declare variables for years, starting amount, interest rate and FutureValue 
			int years;
			double startingAmount;
			double interestRate;
			double futureValue = 0;

			try // try catch to catch any invaild input and display error message
			{
			// Inputed value by the user for years, stating amount and interest rate 
			years = Integer.parseInt(txtInputYears.getText()); 
			startingAmount = Double.parseDouble(txtInputStartingAmount.getText());
			interestRate = Double.parseDouble(txtInputInterestRate.getText());
		

			//this variable String errorOutput ="";
			String errorOutput = "<html>Please Enter a Non-Negative Value for Values;<html>"; //new skill learned also included in this line of code

			// if all the inputs entered are all positive the program will calculate the future value and display it 
			if (InvestmentCalculator.checkInput(years) == true && InvestmentCalculator.checkInput(startingAmount) == true && InvestmentCalculator.checkInput(interestRate) == true) {
				futureValue = (InvestmentCalculator.calculateInvestment(startingAmount, interestRate, years)*100)/100;
				lblfutureValue.setText("Calculated Future Value: $" + twoDecimals.format(futureValue));
			}

			// if any of the input are negative the program will display an error message that a specific input has that has been entered
			// is a negative, this is why there are 3 if statements to check all of the inputs 
			// the program will also display the invalid inputs below the error message 
			// line by line
			else {
				if (InvestmentCalculator.checkInput(years) == false) {
					errorOutput = errorOutput + "<html><br/>Years<html>";
				}
				if (InvestmentCalculator.checkInput(startingAmount) == false) {
					errorOutput = errorOutput + "<html><br/>Starting Amount<html>";
				}
				if (InvestmentCalculator.checkInput(interestRate) == false) {
					errorOutput = errorOutput + "<html><br/>Interest Rate<html>";
				}

				// if any of the inputs entered are invalid then the program will clear the input boxes 
				// display the error message
				txtInputYears.setText ("");
				txtInputStartingAmount.setText (""); 
				txtInputInterestRate.setText ("");
				lblfutureValue.setText (errorOutput);
			}
			}
			catch (Exception error)
			{
				JOptionPane.showMessageDialog (null, "Wrong data entered.");
				// if any of the inputs entered are invalid then the program will clear the input boxes 
				// display the error message
				txtInputYears.setText ("");
				txtInputStartingAmount.setText (""); 
				txtInputInterestRate.setText ("");
			}
			
		}

		//if the clear button is clicked then all the values displayed and numbers entered are clear 
		else if (e.getSource () == btnClear) {
			txtInputYears.setText ("");
			txtInputStartingAmount.setText (""); 
			txtInputInterestRate.setText ("");
			lblfutureValue.setText ("Values Cleared, Please Re-Enter Above");
		}

		//if the exit button is clicked
		else if (e.getSource () == btnExit) {
			//terminate program
			System.exit(0);
		}
	}



	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new InvestmentCalculatorGUI();
	}
}




