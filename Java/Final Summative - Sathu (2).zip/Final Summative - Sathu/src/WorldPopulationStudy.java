import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 * 
 */

/**
 * @author Sathu. K
 * Date: June 16th, 2023
 * Description: This program reads the content of the file into arrays and calculates % of
 * 				the total population of the world for each country. The program outputs the
 * 				information correctly formatted from the arrays.
 * 
 * Method List 
 *            - public static void DisplayInTextArea(String list)
 *            - public static String gatherInformation (String countries[], double population[], double percentage[], double worldPopulation)
 * 			  - public static double countryPercent (double worldPopulation, double population)
 * 			  - public static int findName(String array[], String searchKey)
 * 			  - public static void main(String[] args) throws IOException
 *
 */
public class WorldPopulationStudy {

	/*
	 * Method to create the Output message in JText Area
	 */
	public static void DisplayInTextArea(String list) {
		// Create the output area in JTextArea
		JTextArea outputArea = new JTextArea();

		// Add tab size to format table in a line
		outputArea.setTabSize(12);
		// Set the area to not editable 
		outputArea.setEditable(false);

		// set font and font size
		Font font = new Font("Segoe Script", Font.BOLD, 18);
		outputArea.setFont(font);
		// set colour of the text in JTextArea
		outputArea.setForeground(Color.WHITE);
		// Set the background colour
		outputArea.setBackground(Color.BLACK);

		// put the list into the outputArea
		outputArea.setText(list);

		// display the output area
		JOptionPane.showMessageDialog(null, outputArea);
	}
	/*
	 * Formats information into a list to output in JTextArea
	 */
	public static String gatherInformation (String countries[], double population[], double percentage[], double worldPopulation) {
		// creates two decimal format
		DecimalFormat twoDigits = new DecimalFormat("###,###,###,###.##");
		//**** collects all information into 1 string variable and uses method to display to user.
		String list = "Country\tPopulation\t% of total\n";
		list = list + "=======\t==========\t==========\n";

		// put the array information into output string
		for (int i = 0; i < population.length; i++) {
			if (countries[i] != null) {
				list = list + countries[i] + "\t" + twoDigits.format(Math.round(population[i])) + "\t" + twoDigits.format(percentage[i]) + "%\n";
			}
		}
		return list;	
	}

	/*
	 * Method to calcuate the percentage of popluation compared to world population
	 */
	public static double countryPercent (double worldPopulation, double population) { 

		return (population/worldPopulation) * 100;
	}

	/*
	 * Method to search for a country name
	 */
	public static int findName(String array[], String searchKey) {
		// loop through the array
		for (int i = 0; i < array.length; i = i + 1) {
			// check if the search key is found at the index
			if (array[i].equalsIgnoreCase(searchKey)) {
				// return the index i 
				return i;
			}
		}
		// not found return invaild index
		return -1;
	}

	public static void main(String[] args) throws IOException {

		// delcare 3 data arrays and creates element arrays
		double population [] = null;
		double percentage [] = null;
		String countries [] = null; 

		// declare and intialize variable for total world population
		double worldPopulation = 0;

		// intialize the variable list length
		int listLength = 0;

		// declare file Opener and list
		String fileOpener, list;

		// creates decimal format
		DecimalFormat twoDigits = new DecimalFormat("###,###,###,###.##");

		// creates decimal format
		DecimalFormat output = new DecimalFormat("0.00");

		// open a file to read
		FileReader read = null;
		BufferedReader inputfile = null;

		// declare and intialize boolean
		boolean state = false, state1 = false;
		boolean cancel = false;

		while (state == false) {
			try {
				// prompt user for file name
				fileOpener = JOptionPane.showInputDialog("Choose file you would like to open ", "Worldpopulation.txt");

				if (fileOpener.equals("")) {
					JOptionPane.showMessageDialog(null, "No file Entered! Try Again!");
				}
				else {
					//creating file reader
					read = new FileReader(fileOpener);
					inputfile = new BufferedReader(read);

					listLength = Integer.parseInt(inputfile.readLine());

					// Declare and initialize the variable
					population = new double [listLength];
					percentage = new double [listLength];
					countries = new String [listLength];

					for (int i = 0; i < population.length; i++) { 
						// read file for country name and the current population 11 times
						countries[i] = inputfile.readLine();
						population[i] = Double.parseDouble(inputfile.readLine());
					}
					// the last line in the txt file is the total population
					// that line is read and stored into a variable
					worldPopulation = Double.parseDouble(inputfile.readLine());

					// close the file stream
					read.close();

					// run for loop to calculate the percent of each country
					for (int b = 0; b < population.length; b++) {

						// call the method country Percent to calcuate
						percentage[b] = countryPercent(worldPopulation, population[b]);
					}

					// gathers all information and puts it in the string using method
					list = gatherInformation(countries, population, percentage, worldPopulation);

					// add the total world population to the output list
					list = list + "\nWorld Population is: " + twoDigits.format(Math.round(worldPopulation));

					// call the method to display JTextArea
					DisplayInTextArea(list);

					// make the state true to get out of the while loop 
					state = true; 
				}
				// try catch errors 
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog (null, "File Corrupted");
				state = false;
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog (null, "File not found");
				state = false;
			} catch (NullPointerException e) {
				JOptionPane.showMessageDialog(null, "Program Cancelled");
				state = true;
				cancel = true;
			} 
		}
		while (cancel == false && state == true) {
			// ****** CODE TO SEARCH FOR COUNTRY *****
			String nameToFind = null;

			// prompt user to enter a country name to find
			nameToFind = JOptionPane.showInputDialog(null, "Enter the country you will like to find: ");

			// if cancelled is pressed the program will end the search and move onto the next part of the code
			if (nameToFind == null) {
				JOptionPane.showMessageDialog(null, "Program Cancelled");
				cancel = true;
			}
			else
			{
				// call the method to find the country
				int location = findName(countries, nameToFind);


				// check to see if country name on the list
				if (location < 0) {
					// display error message if name is not on list
					JOptionPane.showMessageDialog(null, "Error! Enter A Country!");

				}
				// if the location of the name is found this code will run 
				else {
					list = "Country\tPopulation\t% of total\n";
					list = list + "=======\t==========\t==========\n";
					list = list + countries[location] + "\t" + twoDigits.format(Math.round(population[location])) + "\t" + twoDigits.format(percentage[location]) + "%\n";
					// call the method to display JTextArea
					DisplayInTextArea(list);
					cancel = true;
				}
			}
		}

		// ***** SORTS INFO ASCENDING ORDER *****
		// sort population in ascending order (lowest to highest)
		for (int i = 0; i < countries.length; i++) {
			// loop through the array
			for (int j = 0; j < countries.length - 1; j ++) {
				// check if the elements are out of order
				if (percentage[j] > percentage[j+1]) {

					// swap the population
					double tempPopulation = population[j];
					population[j] = population[j+1];
					population[j+1] = tempPopulation;

					// swap the percentages
					double tempPercent = percentage[j];
					percentage[j] = percentage[j+1];
					percentage[j+1] = tempPercent;

					// swap the countries
					String tempCountry = countries[j];
					countries[j] = countries[j+1];
					countries[j+1] = tempCountry;
				} // End of If
			} // End of j loop
		} // End of i loop 

		// bulid a string for output
		list = "Sorted in Ascending Order\n";
		// gathers all information and puts it in the string using method
		list = list + gatherInformation(countries, population, percentage, worldPopulation);
		// add the total world population to the output list
		list = list + "\nWorld Population is: " + twoDigits.format(Math.round(worldPopulation));

		// call the method to display JTextArea
		DisplayInTextArea(list);


		// ***** SORTING IN ALPHABETICAL ORDER ********
		for (int i = 0; i < countries.length-1; i++) {
			// loop through the array
			for (int j = 0; j < countries.length-1; j++) {
				 
				int index = countries[j].compareToIgnoreCase(countries[j+1]);
				
				if (index > 0) {
					// swap the population
					double tempPopulation = population[j];
					population[j] = population[j+1];
					population[j+1] = tempPopulation;

					// swap the countries
					String tempCountries = countries[j];
					countries[j] = countries[j+1];
					countries[j+1] = tempCountries;

					// swap the percentage
					double tempPercentage = percentage[j];
					percentage[j] = percentage[j+1];
					percentage[j+1] = tempPercentage;
				}// end of IF

			} // end of j loop

		} // end of i loop

		//Displays text on TextArea
		// builds a output string to display on a dialog box
		list = "Sorted in Alphabetical Order\n";
		// gathers all information and puts it in the string using method
		list = list + gatherInformation(countries, population, percentage, worldPopulation);
		// add the total world population to the output list
		list = list + "\nWorld Population is: " + twoDigits.format(Math.round(worldPopulation));

		DisplayInTextArea(list);


		// **** ALTERING POPULATION OF COUNTRY ****
		while (state == true) {
			try {
				// prompt user to enter country that they would like to change population
				// prompt user to enter a country name to find
				String nameToFind = JOptionPane.showInputDialog(null, "Enter the country you will like to Change population: ");

				// call the method to find the country
				int location = findName(countries, nameToFind);

				if (nameToFind.equals("")) {
					JOptionPane.showMessageDialog(null, "No file Entered! Try Again!");
				}

				else {

					// prompts user for the new population 
					population[location] = Double.parseDouble(JOptionPane.showInputDialog("Enter the new population for " + countries[location]));

					// calculates the new percentage of the new population
					percentage[location] = countryPercent(worldPopulation, population[location]);

					// gathers all information and puts it in the string using method
					list = gatherInformation(countries, population, percentage, worldPopulation);

					// add the total world population to the output list
					list = list + "\nWorld Population is: " + twoDigits.format(Math.round(worldPopulation));

					// call the method to display JTextArea
					DisplayInTextArea(list);

					// declare variable for choice
					int choice;

					// prompt user to ask what type of file they would like to save as
					choice = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter \"1\" if you want to save as a Readable file\n"
							+ "Enter \"2\" if you want tot save as a Printable File "));

					// while loop to catch errors
					while (choice !=1 && choice !=2) {

						// error message 
						JOptionPane.showMessageDialog(null, "Error! Try Again! Enter 1 or 2");

						choice = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter \"1\" if you want to save as a Readable file\n"
								+ "Enter \"2\" "));

					}

					// prompt user for file name
					String fileName = JOptionPane.showInputDialog("Choose file Name: ", "UpdatedPopulationData.txt");

					// if the user enters 1 the file will be formatted in a way of a readable file
					if (choice ==1) {
						FileWriter file3 = new FileWriter(fileName);
						PrintWriter outputMessage = new PrintWriter(file3);

						outputMessage.println(listLength);

						// write each country, population and % of to Readable file
						for (int i = 0; i < countries.length; i++) {
							outputMessage.println( countries[i]);
							outputMessage.println(output.format(population[i]));
						}

						// write the total population
						outputMessage.println(output.format(worldPopulation));

						// close the file
						file3.close();
					}

					// else the program will format as a saveable file
					else {
						FileWriter file3 = new FileWriter(fileName);
						PrintWriter outputMessage = new PrintWriter(file3);

						// write each country, population and % of to saveable file
						for (int i = 0; i < countries.length; i++) {
							outputMessage.println("\nCountry: " + countries[i]);
							outputMessage.println("Population: " + twoDigits.format(Math.round(population[i])));
							outputMessage.println("% of Total :"  + twoDigits.format(percentage[i]) + "%");
						}

						// write the total population
						outputMessage.println("\nThe World Population is " +  twoDigits.format(Math.round(worldPopulation)));

						// close the file
						file3.close();
					}

					// message the user file has been saved
					JOptionPane.showMessageDialog(null,"File has been saved");


					state = false;


				}

				// try catch errors 
			}
			catch (ArrayIndexOutOfBoundsException e) { 
				JOptionPane.showMessageDialog(null,"Error! Enter A Country Name!");
				state = true;
			}
			catch (NumberFormatException e) { 
				JOptionPane.showMessageDialog(null,"Error! Enter a Number!");
				state = true;
			}
			catch (NullPointerException e) {
				JOptionPane.showMessageDialog(null, "Program Cancelled");
				state = false;


			}
		}

		//******* Separating countries with more than 2.7% and less than 2.7% population
		while (state == false) {

			// prompt user to enter either yes or no to separate countries
			int highLowPermission = JOptionPane.showConfirmDialog(null, "Would you like the information to be seperated between Low Country Population and High Country Population?"
					+ "\n\nDISCLAIMER: information will be saved to your downloads.\n\nEnter 'yes' or 'no'","Seperate Countries", JOptionPane. YES_NO_OPTION);

			// if the user enters yes the program will format into 2 separate files of high and low population
			if (highLowPermission ==0) {
				int counterHigh = 0;
				String[] highCountries = new String[listLength];
				double[] highPopulation = new double[listLength], highPercentPopulation = new double[listLength];


				int counterLow = 0;
				String[] lowCountries = new String[listLength];
				double[] lowPopulation = new double[listLength], lowPercentPopulation = new double[listLength];

				for (int i = 0; i < listLength; i++) {
					if (percentage[i] > 2.7) {
						

						highPopulation[counterHigh] = population[i];
						highCountries[counterHigh] = countries[i];
						highPercentPopulation[counterHigh] = percentage[i];
						
						counterHigh++;

					} else {

						lowPopulation[counterLow] = population[i];
						lowCountries[counterLow] = countries[i];
						lowPercentPopulation[counterLow] = percentage[i];
						
						counterLow++;

					}
				}

				// creates fileWriter for LOWPOPULATION.txt
				FileWriter fileWrite = new FileWriter("LOWPOPULATION.txt");
				PrintWriter output3 = new PrintWriter(fileWrite);

				// prints information into file
				output3.println("LOW POPULATION COUNTRIES:\n");

				// for loop to print onto low population file
				for (int i = 0; i < counterLow; i++) {
					if (countries[i] != null) {
						output3.println("\nCountries " + (i+1) + ": " + lowCountries[i]);
						output3.println("Population " + (i+1) + ": " + twoDigits.format(lowPopulation[i]));
						output3.println("% of Total " + (i+1) + ": " + twoDigits.format(lowPercentPopulation[i]) + "%");
					}
				}
				// Closes file
				output3.close();

				// creates fileWriter for HIGHPOPULATION.txt
				fileWrite = new FileWriter("HIGHPOPULATION.txt");
				output3 = new PrintWriter(fileWrite);

				output3.println("HIGH POPULATION COUNTRIES:\n");

				//  for loop to write onto the high population file
				for (int i = 0; i < counterHigh; i++) {
					if (countries[i] != null) {
						output3.println("\nCountries " + (i+1) + ": " + highCountries[i]);
						output3.println("Population " + (i+1) + ": " + twoDigits.format(highPopulation[i]));
						output3.println("% of total " + (i+1) + ": " + twoDigits.format(highPercentPopulation[i]) + "%");
					}
				}

				output3.close();
				// display message to user
				JOptionPane.showMessageDialog(null, "LOWPOPULATION.txt and HIGHPOPULATION.txt has been saved to your downloads");
				JOptionPane.showMessageDialog(null, "Program Finished. Thank You For using Sathu's Program!");
				// change state to get out of loop
				state = true;
			}
			else {
				// display goodbye message
				JOptionPane.showMessageDialog(null, "Program Finished. Thank You For using Sathu's Program!");
				state = true;
			}

		}
	}
}









