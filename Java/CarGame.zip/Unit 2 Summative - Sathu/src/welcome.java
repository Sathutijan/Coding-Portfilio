import java.awt.Color;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

/**
 * 
 */

/**
 * @author Sathu Kugathasan
 * Date: November 2022
 * Description: Sets up the a window to welcome the user to the program,
 *
 */
public class welcome extends JFrame{

	ImageIcon welcome; // Declares the variable, welcome, as a ImageIcon
	
	
	/**
	 * Constructor method/function
	 */
	public welcome() {
		// This builds the window
		super("Automotive Testing"); // The title of the window
		setSize(1000, 580); // Sets the size of the window (width, height)
		setResizable(false); // Prevents user from altering the size of the window 
		
		welcome = new ImageIcon("SathuWelcome.jpg");
		
		setVisible(true); // draws the window (makes window visible)
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		// Puts the code to sleep for 2 seconds, acting as a delay
		try {
			Thread.sleep(2000);
		} catch (Exception e) {}
		
		setVisible(false);		// Hides window
		new CarTrack();
	}

	/**
	 * Calling the paint method
	 */
	public void paint (Graphics g) {
		welcome.paintIcon(this, g, 0, 25);		// paints the image, welcome.png, in1
	
	
	}
	
		
	/**
	 * @param args
	 */
	public static void main(String[] args) {
			new welcome();
	}

}