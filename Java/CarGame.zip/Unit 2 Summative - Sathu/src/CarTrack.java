import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 * 
 */

/**
 * @author Sathu. K
 * Date: April 18, 2023
 * Description: Program (TCSP) that will allow a user to simulate or control the movement
 *              of a prototype automobile. The automobile will race around the track and will
 *              have the option to travel at different speeds and select the car of choice to race.
 *              The car will complete a lap and the program will end 
 *
 */
public class CarTrack extends JFrame{


	// declares all image variables
	ImageIcon background, carIdle, carUp, carRight, carLeft, carDown, gameOver;

	// declares and initializes starting point of car
	int carX = 450, carY = 370; 

	// Declare and Initializes the variables for car speed and delay
	int carSpeed = 0, delay25 = 25;		

	// Initializes variables, name, speed, rating and selectedSpeed, as a String
	String name, selectedSpeed, selectedMap, selectedCar, again;

	// Initialize variable for rating
	int rating;				

	/**
	 * Constructor
	 */
	public CarTrack() {
		// This builds the window

		// The title of the window
		super("Automotive Testing"); 



		setVisible(true); // draws the window (makes window visible)
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		
		//Prompts user for their name, and displays error if user enters nothing into the Dialog Box
		do {
			name = IO.readString("Enter your name: ");

			if (name.equals("")) {
				IO.display("ERROR! You must enter a name. ", new ImageIcon("error.png"));
			}

		} while (name.equals(""));

		// Dropdown Menu in JOptionPane - Found inside the IO Class, it takes the values inside an 
		// array and displays it in a drop down selection menu, to make it easier for user to click on their choice.
		// user selects choice then using if else statements to conclude what will happen if the user selects a specific choice

		// Declares the variable, car Options, as a String array with different car options in the array 
		String[] carOptions = {"Police Car", "Taxi"};

		// reads selection from array of car Options, and prompts user using a drop down menu
		selectedCar = IO.readSelection("Choose car:", carOptions);

		// Checks what the user selected and sets the car corresponding to what they have chose
		if (selectedCar.equals("Police Car")) {
			
			// assign the variables the image icon images to run the code
			carIdle = new ImageIcon("carLeft.png");
			carUp = new ImageIcon("carUp.png");
			carRight = new ImageIcon("carRight.png");
			carDown = new ImageIcon("carDown.png");
			carLeft = new ImageIcon("carLeft.png");	
		}
		else {
			
			// assign the variables the image icon images to run the code
			carIdle = new ImageIcon("taxiLeft.png");
			carUp = new ImageIcon("taxiUp.png");
			carRight = new ImageIcon("taxiRight.png");
			carDown = new ImageIcon("taxiDown.png");
			carLeft = new ImageIcon("taxiLeft.png");
		}
		
		// assigns the game over variable to a image to display after the game is over
		
		gameOver = new ImageIcon("gameOver.png");
		

		// Declares the variable, mapOptions, as a String array with different maps options in the array 
		String[] mapOptions = {"Grassy", "Sandy Dunes", "Water Waves"};

		// reads selection from array of mapOptions, and prompts user using a drop down menu
		selectedMap = IO.readSelection("Choose Map:", mapOptions);
		

		// Checks what the user selected and sets the map corresponding to what they have chose
		if (selectedMap.equals("Grassy")) {
            background = new ImageIcon("trackcourse.jpg");
		}
		else if (selectedMap.equals("Sandy Dunes")) {
			background = new ImageIcon("beach.png");
		}
		else {
			background = new ImageIcon("ocean.png");
		}


		// Declares the variable, speedOptions, as a String array with 5 different speed options in the array 
		String[] speedOptions = {"Super Slow", "Slow", "Normal", "Fast", "Very Fast"};

		// reads selection from array of speedOptions, and prompts user using a drop down menu
		selectedSpeed = IO.readSelection("Choose Speed:", speedOptions);

		// Checks what the user selected and sets the speed corresponding to what they have chose
		if (selectedSpeed.equals("Super Slow")) {
			carSpeed = 1;	
		}
		else if (selectedSpeed.equals("Slow")) {
			carSpeed = 3;
		}
		else if (selectedSpeed.equals("Normal")) {
			carSpeed = 5;
		}
		else if (selectedSpeed.equals("Fast")) {
			carSpeed = 7;
		}
		else {
			carSpeed = 9;
		}


		setSize(800, 490);   // Sets the size of the window (width, height)
		setResizable(false); // Prevents user from altering the size of the window 
	}

	/**
	 * Calling the paint method
	 */
	public void paint (Graphics g) {	

		background.paintIcon(this, g, 0, 0);			// Paints the image background, at (0,0)
		carIdle.paintIcon(this, g, carX, carY);	        // Paints the car at carX and carY
		g.setColor(Color.WHITE);                        // set colour of my pen

		for (int i = 3; i >= 0; i--) {

			// Paints background and car each time
			background.paintIcon(this, g, 0, 0);			// Paints the image background, at (0,0)
			carIdle.paintIcon(this, g, carX, carY);	        // Paints the car at carX and carY

			// https://stackoverflow.com/questions/24278648/how-to-change-font-in-java-gui-application
			// How to change font and font size
			
			// displays user's name + requested speed
			g.setFont(new Font("TimesRoman", Font.PLAIN, 30));
			g.drawString("Driver: " + name, 280, 250);          // prints the your name and the speed of the car
			g.drawString("Speed: " + selectedSpeed, 280, 280);

			g.setFont(new Font("TimesRoman", Font.PLAIN, 30)); // Setting fonts to Times New Roman, size 30

			if (i > 0) {
				//**** displays the count down
				g.drawString("" + i, 350, 200);						// Drawing the variable, i, at (350, 200)
			}
			else {
				g.drawString("GO!", 340, 200);						// Drawing the variable, i, at (340, 200)
			}


			// puts program to sleep for 1 second
			try {
				Thread.sleep(1000);
			} catch (Exception e) {}
		}


		// Makes car go left by carSpeed every 25 ms
		for (int W = 450; W > 50; W = W - carSpeed) {
			background.paintIcon(this, g, 0, 0);		     // Paints the image background, at (0,0)
			carLeft.paintIcon(this, g, W, carY);	         // Paints the car at designated coordinates
			g.drawString("Driver: " + name, 280, 250);       // prints the your name and the speed of the car
			g.drawString("Speed: " + selectedSpeed, 280, 280);

			// Puts code to sleep for 25 ms
			try {
				Thread.sleep(25);
			} catch (Exception e) {}

		}


		// Makes car go up by carSpeed every 25 ms
		for (int Y = 280; Y > 50; Y = Y - carSpeed) {
			background.paintIcon(this, g, 0, 0);		     // Paints the image background, at (0,0)
			carUp.paintIcon(this, g, 50, Y);	             // Paints the car at designated coordinates
			g.drawString("Driver: " + name, 280, 250);       // prints the your name and the speed of the car
			g.drawString("Speed: " + selectedSpeed,280, 280);

			// Puts code to sleep for 25 ms
			try {
				Thread.sleep(25);
			} catch (Exception e) {}
		}

		// Makes car go to the right by carSpeed every 25 ms
		for (int X = 50; X < 550; X = X + carSpeed) {
			background.paintIcon(this, g, 0, 0);		     // Paints the image background, at (0,0)
			carRight.paintIcon(this, g, X, 50);	             // Paints the car at designated coordinates
			g.drawString("Driver: " + name, 280, 250);       // prints the your name and the speed of the car
			g.drawString("Speed: " + selectedSpeed, 280, 280);

			// Puts code to sleep for 25 ms
			try {
				Thread.sleep(25);
			} catch (Exception e) {}

		}

		// Makes car go down by carSpeed every 25 ms
		for (int Z = 50; Z < 305; Z = Z + carSpeed) {
			background.paintIcon(this, g, 0, 0);		     // Paints the image background, at (0,0)
			carDown.paintIcon(this, g, 580, Z);	             // Paints the car at designated coordinates
			g.drawString("Driver: " + name, 280, 250);       // prints the your name and the speed of the car
			g.drawString("Speed: " + selectedSpeed, 280, 280);

			// Puts code to sleep for 25 ms
			try {
				Thread.sleep(25);
			} catch (Exception e) {}

		}
		// Makes car go left by carSpeed every 25 ms
		for (int W = 560; W > 300; W = W - carSpeed) {
			background.paintIcon(this, g, 0, 0);		     // Paints the image background, at (0,0)
			carLeft.paintIcon(this, g, W, carY);	         // Paints the car at designated coordinates
			g.drawString("Driver: " + name, 280, 250);       // prints the your name and the speed of the car
			g.drawString("Speed: " + selectedSpeed, 280, 280);
			
			// Puts code to sleep for 25 ms
			try {
				Thread.sleep(25);
			} catch (Exception e) {}

		}
		// Paint game over message at the designated coordinates
		gameOver.paintIcon(this, g, 150, 150);

		// Puts code to sleep for 3200 ms
		try {
			Thread.sleep(3200);
		} catch (Exception e) {}

		setVisible(false); // Makes simulation window not visible

		// Prompts user to enter their rating of the game
		rating = IO.readInt("Please give us a rating! Enter a rating from 1 to 10.");

		// Error message for rating and prompts user again if user enters anything other then a number from 1-10
		while (rating > 10 || rating < 1) {
			IO.display("ERROR! You must enter a rating from 1 to 10, inclusive. ", new ImageIcon("error.png"));

			// prompt user again
			rating = IO.readInt("Enter a rating from 1 to 10.");
		}

		
		// Thank user for using my program
		IO.display("Thank you the rating! Hope you have a wonderful day! Program Devolped By Sathu. K");
		
		// Display good bye message
		IO.display("", new ImageIcon("goodbye.gif"));

	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new welcome();
	



	}

}
